package org.example.lawnmpwer.auth.controller;

import org.example.lawnmpwer.auth.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.Map;

@RestController
@RequestMapping("/auth")
@CrossOrigin // 解决跨域请求的问题
public class AuthController {

    @Autowired
    private UserService userService; // 注入业务类

    @PostMapping("/login")
    public Map<String, String> login(@RequestBody Map<String, String> body) {
        String username = body.getOrDefault("username", "");
        String password = body.getOrDefault("password", "");

        try {
            // 调用数据库验证逻辑
            String token = userService.login(username, password);
            return Map.of("token", token);
        } catch (Exception e) {
            // 登录失败抛出 401
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, e.getMessage());
        }
    }

    @PostMapping("/register")
    public Map<String, String> register(@RequestBody Map<String, String> body) {
        String username = body.getOrDefault("username", "");
        String password = body.getOrDefault("password", "");

        if(username.isBlank() || password.isBlank()){
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "用户名或密码不能为空");
        }

        try {
            userService.register(username, password);
            return Map.of("message", "注册成功！");
        } catch (Exception e) {
            // 注册失败（如重名）抛出 400
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage());
        }
    }
}