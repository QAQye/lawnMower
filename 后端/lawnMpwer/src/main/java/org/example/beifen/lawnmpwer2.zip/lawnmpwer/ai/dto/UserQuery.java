package org.example.lawnmpwer.ai.dto;


public record UserQuery(String message) {}