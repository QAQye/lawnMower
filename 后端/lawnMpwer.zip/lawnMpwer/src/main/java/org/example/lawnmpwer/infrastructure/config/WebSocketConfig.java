package org.example.lawnmpwer.infrastructure.config;

import org.example.lawnmpwer.robot.websocket.FrontendControlHandler;
import org.example.lawnmpwer.robot.websocket.FrontendStreamHandler;
import org.example.lawnmpwer.robot.websocket.RobotControlHandler;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.socket.config.annotation.EnableWebSocket;
import org.springframework.web.socket.config.annotation.WebSocketConfigurer;
import org.springframework.web.socket.config.annotation.WebSocketHandlerRegistry;

@Configuration
@EnableWebSocket
public class WebSocketConfig implements WebSocketConfigurer {

    private final RobotControlHandler robotControlHandler;
    private final FrontendStreamHandler frontendStreamHandler;
    private final FrontendControlHandler frontendControlHandler;

    public WebSocketConfig(RobotControlHandler robotControlHandler,
                           FrontendStreamHandler frontendStreamHandler,
                           FrontendControlHandler frontendControlHandler) {
        this.robotControlHandler = robotControlHandler;
        this.frontendStreamHandler = frontendStreamHandler;
        this.frontendControlHandler = frontendControlHandler;
    }

    @Override
    public void registerWebSocketHandlers(WebSocketHandlerRegistry registry) {
        // 前端控制入口
        registry.addHandler(frontendControlHandler, "/ws/frontend/control")
                .setAllowedOriginPatterns("*");

        // 前端视频流入口（原来的保留）
        registry.addHandler(frontendStreamHandler, "/ws/frontend/stream")
                .setAllowedOriginPatterns("*");

        // 旧的小车 WebSocket 控制入口先保留，过渡期不删
        registry.addHandler(robotControlHandler, "/ws/robot/control")
                .setAllowedOriginPatterns("*");
    }
}