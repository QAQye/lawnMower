package org.example.lawnmpwer.detect;

import org.example.lawnmpwer.detect.CarStreamService;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import java.io.IOException;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

@Component
public class FrontendStreamHandler extends TextWebSocketHandler {

    // 线程安全地存储所有打开了网页的用户
    private static final Set<WebSocketSession> sessions = ConcurrentHashMap.newKeySet();

    private final CarStreamService carStreamService;

    // ⭐ 构造函数注入，使用 @Lazy 延迟加载，完美解决 Spring 循环依赖报错
    public FrontendStreamHandler(@Lazy CarStreamService carStreamService) {
        this.carStreamService = carStreamService;
    }

    @Override
    public void afterConnectionEstablished(WebSocketSession session) {
        sessions.add(session);
        System.out.println("📺 [前端推流] 网页打开！当前观看人数: " + sessions.size());

        // ⭐ 关键逻辑：第一个人打开网页时，唤醒小车！
        if (sessions.size() == 1) {
            carStreamService.connectToRobot();
        }
    }

    @Override
    public void afterConnectionClosed(WebSocketSession session, CloseStatus status) {
        sessions.remove(session);
        System.out.println("📺 [前端推流] 网页关闭。当前观看人数: " + sessions.size());

        // ⭐ 关键逻辑：最后一个人离开网页时，让小车休息！
        if (sessions.isEmpty()) {
            carStreamService.disconnectFromRobot();
        }
    }

    // 广播画面给所有在线用户
    public void broadcast(String payload) {
        TextMessage message = new TextMessage(payload);
        for (WebSocketSession session : sessions) {
            if (session.isOpen()) {
                try {
                    session.sendMessage(message);
                } catch (IOException e) {
                    System.err.println("❌ 发送画面失败: " + e.getMessage());
                }
            }
        }
    }

    // 提供给 CarStreamService 判断是否还有人看
    public boolean hasViewers() {
        return !sessions.isEmpty();
    }
}