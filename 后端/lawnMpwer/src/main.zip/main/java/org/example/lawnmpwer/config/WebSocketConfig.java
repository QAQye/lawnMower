package org.example.lawnmpwer.config;

import org.example.lawnmpwer.remote.RobotControlHandler;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.socket.config.annotation.EnableWebSocket;
import org.springframework.web.socket.config.annotation.WebSocketConfigurer;
import org.springframework.web.socket.config.annotation.WebSocketHandlerRegistry;

@Configuration
@EnableWebSocket
public class WebSocketConfig implements WebSocketConfigurer {

    @Override
    public void registerWebSocketHandlers(WebSocketHandlerRegistry registry) {
        // 定义前端连接的路径: ws://localhost:8080/ws/robot
        registry.addHandler(new RobotControlHandler(), "/ws/robot")
                .setAllowedOrigins("*"); // 允许跨域
    }
}
