package org.example.lawnmpwer.config;
import org.example.lawnmpwer.detect.FrontendStreamHandler;
import org.example.lawnmpwer.remote.RobotControlHandler;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.socket.config.annotation.EnableWebSocket;
import org.springframework.web.socket.config.annotation.WebSocketConfigurer;
import org.springframework.web.socket.config.annotation.WebSocketHandlerRegistry;

@Configuration
@EnableWebSocket
public class WebSocketConfig implements WebSocketConfigurer {

    private final FrontendStreamHandler frontendStreamHandler;

    // 注入我们刚写的处理器
    public WebSocketConfig(FrontendStreamHandler frontendStreamHandler) {
        this.frontendStreamHandler = frontendStreamHandler;
    }

    @Override
    public void registerWebSocketHandlers(WebSocketHandlerRegistry registry) {
        // 原有的控制接口
        registry.addHandler(new RobotControlHandler(), "/ws/robot")
                .setAllowedOrigins("*");

        // ⭐ 新增：前端接收视频流的 WebSocket 接口
        registry.addHandler(frontendStreamHandler, "/ws/stream")
                .setAllowedOrigins("*");
    }
}