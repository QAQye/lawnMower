package org.example.lawnmpwer.dto;


public record UserQuery(String message) {}