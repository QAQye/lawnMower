package org.example.lawnmpwer.auth.service;
import com.baomidou.mybatisplus.extension.service.IService;
import org.example.lawnmpwer.auth.entity.User;

public interface UserService extends IService<User> {
    String login(String username, String password);
    void register(String username, String password);
}