package org.example.lawnmpwer.ai.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.example.lawnmpwer.ai.dto.UserQuery;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@RestController
@RequestMapping("/ai")
public class AiController {

    // 记得确保这个 Key 里面是有余额的
    private final String API_KEY = "sk-6edcf8f03aa7468881a54cb6e58db38b";
    private final String API_URL = "https://api.deepseek.com/chat/completions";

    // 创建一个专门的线程池来处理流式输出，防止阻塞主服务器线程
    private final ExecutorService executor = Executors.newCachedThreadPool();

    @PostMapping(value = "/ask", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public SseEmitter askDeepSeekStream(@RequestBody UserQuery query) {
        // 设置 2 分钟超时，给足 AI 思考时间
        SseEmitter emitter = new SseEmitter(120000L);

        executor.execute(() -> {
            try {
                ObjectMapper mapper = new ObjectMapper();
                // 开启 "stream": true
                Map<String, Object> bodyMap = Map.of(
                        "model", "deepseek-chat",
                        "stream", true,
                        "messages", List.of(
                                Map.of("role", "system", "content", "你是一个专业的智能割草机视觉算法专家。你的核心研究方向是【基于单目相机的视觉数据采集】、【YOLO实时目标检测】、【OpenCV图像处理】以及算法在边缘设备（如树莓派）上的部署。请基于这些专业背景解答问题，给出具有工程实践价值的建议，并始终使用Markdown排版格式清晰回答"),
                                Map.of("role", "user", "content", query.message())
                        )
                );
                String requestBody = mapper.writeValueAsString(bodyMap);

                HttpClient client = HttpClient.newHttpClient();
                HttpRequest request = HttpRequest.newBuilder()
                        .uri(URI.create(API_URL))
                        .header("Content-Type", "application/json")
                        .header("Authorization", "Bearer " + API_KEY)
                        .POST(HttpRequest.BodyPublishers.ofString(requestBody))
                        .build();

                HttpResponse<InputStream> response = client.send(request, HttpResponse.BodyHandlers.ofInputStream());

                // 🚨 如果 DeepSeek 官方报错（如欠费），直接把错误打印到前端界面
                if (response.statusCode() != 200) {
                    BufferedReader errorReader = new BufferedReader(new InputStreamReader(response.body()));
                    String errorMsg = errorReader.readLine();
                    System.err.println("DeepSeek API 报错: " + errorMsg);

                    String tip = "{\"choices\":[{\"delta\":{\"content\":\"**[系统提示]** AI 接口连接失败！状态码: " + response.statusCode() + "。请检查后端控制台，大概率是 API Key 余额不足或已过期。\"}}]}";
                    emitter.send(SseEmitter.event().data(tip, MediaType.TEXT_PLAIN));
                    emitter.complete();
                    return;
                }

                // 正常处理流式数据
                BufferedReader reader = new BufferedReader(new InputStreamReader(response.body()));
                String line;
                while ((line = reader.readLine()) != null) {
                    if (line.startsWith("data: ")) {
                        String data = line.substring(6).trim();
                        if ("[DONE]".equals(data)) {
                            // 结束标志
                            emitter.send(SseEmitter.event().data("[DONE]"));
                            break;
                        }
                        // 🌟 核心：使用 TEXT_PLAIN 防止 Spring 自动给 JSON 字符串加双引号
                        emitter.send(SseEmitter.event().data(data, MediaType.TEXT_PLAIN));
                    }
                }
                emitter.complete();

            } catch (Exception e) {
                System.err.println("流式输出异常: " + e.getMessage());
                emitter.completeWithError(e);
            }
        });

        return emitter;
    }
}